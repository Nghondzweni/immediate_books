# immediate_books
This is a book-shelf android application developed in android studio using Java programming language. It utilises the google books api and allows users to keep add and remove books from their shelf. It also allows users to add favourites and To-Read books
