package com.example.immediatebooks;

import com.google.gson.annotations.SerializedName;

public class Post {

//    @SerializedName("id")
//    private String bookID;
//
//    private String title;
//
//    private String subtitle;
//
//    private String authors;
//
//    public String getBookID() {
//        return bookID;
//    }
//
//    public String getTitle() {
//        return title;
//    }
//
//    public String getSubtitle() {
//        return subtitle;
//    }
//
//    public String getAuthors() {
//        return authors;
//    }
}
